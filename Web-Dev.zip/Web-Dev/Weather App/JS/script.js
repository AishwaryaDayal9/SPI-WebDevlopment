// window.alert("Hello World!");
// 28296fc4a059820f998a8314c0536522
// https://api.openweathermap.org/data/2.5/weather?q=Lucknow&appid=28296fc4a059820f998a8314c0536522
// https://api.openweathermap.org/data/2.5/weather?units=metric&q=Lucknow&appid=0fde24f18909b27ce870124bbcdf96d5

async function weather(){
    let city=document.querySelector('#search>input').value;
    console.log(city);
    const url="https://api.openweathermap.org/data/2.5/weather?units=metric&q="+city+"&appid=0fde24f18909b27ce870124bbcdf96d5";
    const res=await fetch(url);
    const data=await res.json();
    console.log(data);
    temp.innerHTML=Math.round(data.main.temp)+"℃";
    humidity.innerHTML=data.main.humidity+"%";
    wind.innerHTML=data.wind.speed+"km/h";
    if(data.weather[0].main=="Mist"){
        document.querySelector('#main>img').src="IMG/mist.png"
    }
    else if(data.weather[0].main=="Clear"){
        document.querySelector('#main>img').src="IMG/clear.png"
    }
    else if(data.weather[0].main=="Haze"){
        document.querySelector('#main>img').src="IMG/haze.png"
    }
    else if(data.weather[0].main=="Clock"){
        document.querySelector('#main>img').src="IMG/clock.jpg"
    }
    else if(data.weather[0].main=="Rain"){
        document.querySelector('#main>img').src="IMG/rain.jpg"
    }
    else if(data.weather[0].main=="Snow"){
        document.querySelector('#main>img').src="IMG/snow.jpg"
    }
    else if(data.weather[0].main=="Wind"){
        document.querySelector('#main>img').src="IMG/wind.jpg"
    }
    else if(data.weather[0].main=="Drizzle"){
        document.querySelector('#main>img').src="IMG/drizzle.jpg"
    }
    cityname.innerHTML=data.name;
}